
-- DECLARE
--       U_LOCATION_ID department.LOCATION_ID%TYPE;
    begin

        update Department

        set LOCATION_ID='HQ-BLR-101'

        WHERE LOCATION_ID LIKE 'HQ%';

END;


/

