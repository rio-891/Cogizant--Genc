DECLARE
     new_depart_id  department.department_id%TYPE;
    BEGIN
       SELECT MAX (department_id) + 10 INTO new_depart_id FROM department;
  
       INSERT INTO department (department_id, department_name, location_id)
            VALUES (new_depart_id, 'TESTING', 'CHN-102');
    
    END;
/