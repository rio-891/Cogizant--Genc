declare
    Radius number(5);
    Area number(7,2);
    pi constant number (4,2):=3.14;
    
    begin
        Radius:=3;
        while Radius<=7
        loop
            area:=pi*power(Radius,2);
            insert into circle values(Radius,Area );
            Radius:=Radius+1;
        end loop;
end;
/
-- select * from circle;