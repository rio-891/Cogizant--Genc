﻿using Quartz;
using Quartz.Impl;
using System;
namespace MySchedulerApp
{
    public class Scheduler
    {
        public void Start(DateTime date)
        {
            IScheduler scheduler = (IScheduler)StdSchedulerFactory.GetDefaultScheduler();
            scheduler.Start();
            IJobDetail job = JobBuilder.Create<Job>().Build();
            ITrigger trigger = TriggerBuilder.Create().WithIdentity("IDGJob", "IDG").StartAt(date).WithPriority(1).Build();
            scheduler.ScheduleJob(job, trigger);
        }
    }
}