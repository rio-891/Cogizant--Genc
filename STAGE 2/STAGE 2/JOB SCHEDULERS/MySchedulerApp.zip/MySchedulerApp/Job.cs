﻿using Quartz;
namespace MySchedulerApp
{
    public class Job : IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }
    }
}