﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySchedulerApp
{
    public partial class FrmScheduler : Form
    {
        public FrmScheduler()
        {
            InitializeComponent();
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "MM/dd/yyyy hh:mm:ss";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnScheduleJob_Click(object sender, EventArgs e)
        {
            DateTime date = dateTimePicker1.Value;
            Scheduler sc = new Scheduler();
            sc.Start(date);
        }
    }
}
