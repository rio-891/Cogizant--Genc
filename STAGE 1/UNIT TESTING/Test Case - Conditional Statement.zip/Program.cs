//THIS IS FOR REFERENCE ONLY. YOU NEED NOT MAKE ANY CHANGES HERE
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoAppCore
{
    public class Program
    {
        
        
        public static string CalculateGrade(float mark)
        {
            string grade="";
            if(mark <40)
                grade="FAIL";
            else if(mark >= 40)
                grade="PASS";
            return grade;    
        }
    }
}
