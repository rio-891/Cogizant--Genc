using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace AssetProject
{
    //Add required NUnit test attribute
    [TestFixture]
    public class FunctionalTest
    {
        //Add required test methods
        [Test]
        //[TestCase(new Asset("first","ncat","mod1",1005.0))]
        public void TestValidAsset(){
            AssetBO a = new AssetBO();
            
            string s = a.ValidateAsset(new Asset("first","ncat","mod1",1005.0));
            Assert.That(s,Does.Contain("Asset Valid").IgnoreCase);
        }
        [Test]
        public void TestInValidAsset()
        {
            AssetBO a = new AssetBO();
            // var x = a.ValidateAsset(new Assset("first","ncat","mod1",10.0);
            // Assert.That(x,Is.Typeof<string>());
            Assert.That(()=>a.ValidateAsset(new Asset("first","ncat","mod1",10.0)),Throws.TypeOf<InvalidCostException>());
        }
        
    }
}