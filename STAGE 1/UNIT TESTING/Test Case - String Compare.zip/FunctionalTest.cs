using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace DemoAppCore
{
    //Add required NUnit test attribute
    [TestFixture]
    class FunctionalTest
    {
        //Add required test methods
        [Test]
        public static void value()
        {
            var msg = Program.FinalMessage();
            StringAssert.Contains(msg,"The total is Rs.7600");
        }
    }
}