function validateEmail(email)
{
var emailformat = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;
 var result="";
if(email.match(emailformat))
{
  result = 'Valid email address!';
}
else
{
  result = 'Invalid email address!';
}
return result;
}
console.log(validateEmail("info123@example.com"));