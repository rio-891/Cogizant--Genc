function modifyString(str)
{
    str=str.split(" ").join("");
    str=str.toLowerCase();
    return str;
}

function uniqueCharacters(str)
{
    string=modifyString(str);
    
    var uniq="";
    for (var i=0;i<string.length;i++)
    {
        if (uniq.includes(string[i])===false)
        {
            uniq+=string[i]
        }
    }
    return uniq;
}
