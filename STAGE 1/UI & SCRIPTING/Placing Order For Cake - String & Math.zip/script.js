function OrderCake(str) {
  //fill the code
var kg,cake,cakeid,cakesize;
  cakesize=str.length;
  kg=str.substring(0,4);
  cakeid=str.substring(cakesize-3);
  cake=str.substring(4,cakesize-3);
    
  var weight=(parseInt(kg)/1000);
    var kgw=Math.round(weight);
  var cost=Math.round((weight)*450);
  
  return "Your order for "+kgw+" kg "+cake+" cake has been taken. You are requested to pay Rs. "+cost+" on the order no "+cakeid;
}