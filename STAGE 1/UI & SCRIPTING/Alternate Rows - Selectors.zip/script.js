$("table").find("tr:even").css({'background-color':'lightpink'});
$("table").find("tr:odd").css({'background-color':'lightblue'});
$("table").find("caption").css({'background-color':'lightblue'});