$('p').css('color','orange');
$('p:last').css('font-size','50%');
$('.flavours > li').css('background-color','lightblue');
$('#icecreamfloats > li').css('background-color','orange');
$('.flavours').css('font-size','120%');

// WRITE YOUR CODE HERE