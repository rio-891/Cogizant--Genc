function wordPlay(num) {
  if (num < 1) return "Not Valid";
  if (num > 50) return "Range is High";

  let str = "";

  for (i = 1; i <= num; i++) {
      if (i % 15 === 0) str += " Jump";
      else if (i % 3 === 0) str += " Tap";
      else if (i % 5 === 0) str += " Clap";
      else str += ` ${i}`;
  }

  return str;
}

console.log(wordPlay(16));